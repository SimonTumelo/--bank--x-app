/*
Bank X has defined a specification for a new Banking Application.
In keeping up with the trends around the world, Bank X wants to be able to allow both internal and external systems to connect with the new application. 
The Application must allow new customers to be onboarded and to obtain new accounts. Each customer with be provided with a Current and Savings account upon onboarding and will have their Savings Account credited with a joining bonus of R500.00. 
Customers should be able to move money between their accounts.
Only the Current Account should be enabled to make payments to other accounts.
All payments made into the Savings Account will be credited with a 0.5% interest of the current balance. 
All payments made from the customer’s account will be charged 0.05% of the transaction amount. 
The application must keep track of every transaction performed on the accounts and allow other systems to retrieve these. 
The system must send out notifications to the customer for every transaction event. 
Bank X also want to allow Bank Z to be able debit or credit the customer’s account for any transactions that were handled by Bank Z on behalf of Bank X.
Bank Z should be able to send a single immediate transaction or a list of transactions which should be processed immediately.
Bank Z should be able to send Bank X a list of transactions that they processed on behalf of Bank X at the end of the business day for reconciliation
 */
package bank.x;

import java.util.Scanner;

/**
 *
 * @author Tumelo Matlou
 * @Date 29 Mar 2023
 * @Project Bank-X
 */
public class BankDetails {
    public String AccountHolderName;
    public String AccountNumber;
    public String AccountType;
    public Long Deposit;
    public Long BankBalance;
    public Long NewBalance;
    public final Integer OnboardBalance = 500;
    
    Scanner Input = new Scanner(System.in);
    
    //Method for New Account 
    public void OpenAccount(){
        System.out.println("Please enter Account Holder Name");
        AccountHolderName = Input.nextLine();
        
        if(AccountHolderName == null ){
            System.out.println("Name cannot be empty");
            
        }else
        {
            System.out.println("Welcome " + AccountHolderName);
        }
        
        System.out.println("Please enter Account Number");
        AccountNumber = Input.nextLine();
        
        
        
        System.out.println("only SAVINGS or CURRENT Account is allowed \n"
                + "=====================================================");
        System.out.println("Please enter Account Type");
        AccountType = Input.nextLine();
        
        if ("SAVINGS".equals(AccountType) || "CURRENT".equals(AccountType)  ){
            System.out.println("The Account type is approved");
        }else
        {
          System.out.println("Account Type Does not exist,Please try again !!! ");
        }
        ShowAccountDetails();
        OnboardBalance();
    }

    public void ShowAccountDetails(){
        System.out.println("-----Account Holder Details----");
        System.out.println("Account Holder Name \n "
                + " " + " " + AccountHolderName + " Account Number " + AccountNumber + "Account Type" + AccountType );
    }
    public void OnboardBalance(){
        long SavingsBalance = 0;
        
        if ("SAVINGS".equals(AccountType)){
            BankBalance = SavingsBalance + OnboardBalance;
            System.out.println("Welcome " + AccountHolderName + " Here's a gift from Bank X " + " R" + OnboardBalance + " \n"
                    + " and your new savings \n"
                    + " Balance is " + " R " + BankBalance);
            
        }  
    }
    public void Deposit()
    {
        OnboardBalance();
        long DepositAmount = 0;  
        long SavingsBalance = 0 ,CurrentBalance = 0;
        if("SAVINGS".equals(AccountType))
        {
           // BankBalance = SavingsBalance;
            System.out.println("Enter the amount you want to deposit: ");  
            DepositAmount = Input.nextLong(); 
            
            if (DepositAmount < 0){
                System.out.println("Please enter Valid amount: "); 
            }
            SavingsBalance = BankBalance + DepositAmount;
            System.out.println("Your New SAVINGS Balance Is " + " " + SavingsBalance);
        }else if("CURRENT".equals(AccountType)){
            //BankBalance = CurrentBalance;
            System.out.println("Enter the amount you want to deposit: ");  
            DepositAmount = Input.nextLong();
             if (DepositAmount < 0)
             {
                System.out.println("Please enter Valid amount: "); 
            }
        }
             CurrentBalance = BankBalance + DepositAmount;
            System.out.println("Your New Balance Is " + " " + CurrentBalance);
    }

    public void Transfer(){
    System.out.println("App Not Activated");
    } 
    
    public void Withdraw()
    {
        long Savings = 0;
        long Current = 0;
        long WithdrawalAmount;
        int option;
          
        do{
            
            System.out.println("Please select which account you wish to withdraw from");
            System.out.println("1 . SAVINGS \n 2 .  CURRENT \n 3 . Exit");
            option = Input.nextInt();
        switch(option)
        {
            case 1:
                      System.out.println("Enter the amount you want to withdraw: ");  
                      WithdrawalAmount = Input.nextLong();  
        if (Savings >= WithdrawalAmount) {  
            Savings = Savings - WithdrawalAmount;  
            System.out.println("Balance after withdrawal: " + Savings);  
        } else {  
            System.out.println("Your balance is less than " + WithdrawalAmount + "\tTransaction failed...!!" );  
        } 
                break;      
           case 2:
                 System.out.println("Enter the amount you want to withdraw: ");  
                 WithdrawalAmount = Input.nextLong();  
            if (Current >= WithdrawalAmount) {  
            Current = Current - WithdrawalAmount;  
            System.out.println("Balance after withdrawal: " + Current);  
        } else 
        {  
            System.out.println("Your balance is less than " + WithdrawalAmount + "\tTransaction failed...!!" );  
        } 
                break;   
            case 3:
                System.out.println("Thank you for using Bank X online service \n  "
                        + " See you again soon ");
                break;
        }
      }while(option !=3);   
}   
    public void TransactionHistory()
    {
        System.out.print("\t|"+ Deposit );   
    }
    public void Payment(){
      //double Interest = 0.5;
      String PaymentAccount =  " " ;
      int SavingsBalance,CurrentBalance;
      
     
      if ("SAVINGS".equals(PaymentAccount)){
      SavingsBalance =  (int) (BankBalance * 0.5);
      System.out.println(SavingsBalance + " SAVINGS");
      }
      else if("CURRENT".equals(PaymentAccount))
      {
          CurrentBalance =  (int) (0.5 * BankBalance);
          System.out.println(CurrentBalance + " Current");
      }
      
    }
}
